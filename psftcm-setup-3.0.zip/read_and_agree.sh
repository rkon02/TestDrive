export tenancyId="${tenancyId}";		
export authUserId="${authUserId}";
export keyFingerprint="${keyFingerprint}";
export privateKeyPath="${privateKeyPath}";
	
. oci_curl

#listingId="ocid1.appcataloglisting.oc1..aaaaaaaanqkuc5fit7nax6fltqgox7ucpqxvlaeiqktr2qyih754y5mzrowq"
#resourceVersion="OCI_X86_64_PSFTCM_P09_OL_6.10_01"
#compOcid="ocid1.compartment.oc1..aaaaaaaarhyu47htmeannvdgljct464exzke2mi7sd4sksrly5elvlasuiya"

	

listingId=$${1}
resourceVersion=$${2}
compOcid=$${3}
region=$${4}
EP="iaas.$${region}.oraclecloud.com"


ag="$${resourceVersion}.agreements"
oci-curl $${EP} GET /20160918/appCatalogListings/$${listingId}/resourceVersions/$${resourceVersion}/agreements > $${ag}

oci_terms=`jq .oracleTermsOfUseLink $${ag} | tr -d "\r\n'\"" `


psft_eula=`jq .eulaLink $${ag} | tr -d "\r\n'\"" `


echo "Sending agreement..."
comp_agree=comp_agree.json
jq '.compartmentId = "'$${compOcid}'"' $${ag} > $${comp_agree}
jq . comp_agree.json  
oci-curl $${EP}  POST $${comp_agree} /20160918/appCatalogSubscriptions
